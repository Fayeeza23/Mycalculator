package com.example.mycalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    double num1 = 0, num2 = 0;
    TextView result;
    boolean Add, Sub, Mul, Div, Decimal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result = findViewById(R.id.result);

    }
    public void bttn1(View view) {
        result.setText(result.getText() + "1");
    }
    public void bttn2(View view) {
        result.setText(result.getText() + "2");
    }
    public void bttn3(View view) {
        result.setText(result.getText() + "3");
    }
    public void bttn4(View view) {
        result.setText(result.getText() + "4");
    }
    public void bttn5(View view) {
        result.setText(result.getText() + "5");
    }
    public void bttn6(View view) {
        result.setText(result.getText() + "6");
    }
    public void bttn7(View view) {
        result.setText(result.getText() + "7");
    }
    public void bttn8(View view) {
        result.setText(result.getText() + "8");
    }
    public void bttn9(View view) {
        result.setText(result.getText() + "9");
    }
    public void bttn0(View view) {
        result.setText(result.getText() + "0");
    }

    public void decimal(View view) {
        if (Decimal) {
        } else {
            result.setText(result.getText() + ".");
            Decimal = true;
        }
    }
    public void add (View view) {
        if (result.getText().length() != 0) {
            num1 = Double.parseDouble(result.getText() + "");
            Add = true;
            Decimal = false;
            result.setText(null);
        }
    }
    public void sub(View view) {
        result.setText(result.getText()+"");
        if (result.getText().length() != 0) {
            num1 = Double.parseDouble(result.getText() + "");
            Sub = true;
            Decimal = false;
            result.setText(null);
        }
    }
    public void mul(View view) {
        if (result.getText().length() != 0) {
            num1 = Double.parseDouble(result.getText() + "");
            Mul = true;
            Decimal = false;
            result.setText(null);
        }
    }
        public void div(View view) {
            if (result.getText().length() != 0) {
                num1 = Double.parseDouble(result.getText() + "");
                Div = true;
                Decimal = false;
                result.setText(null);
            }
        }
    public void equals(View view) {
        if (Add || Sub || Mul || Div) {
            num2 = Double.parseDouble(result.getText() + "");
        }
        if (Add) {
            result.setText(num1 + num2 + "");
            Add = false;
        }
        if (Sub) {
            result.setText(num1 - num2 + "");
            Sub = false;
        }
        if (Mul) {
            result.setText(num1 * num2 + "");
            Mul = false;
        }
        if (Div) {
            result.setText(num1 / num2 + "");
            Div = false;
        }
    }
    public void del(View view) {
        result.setText("");
        num1 = 0;
        num2 = 0;
    }
}

